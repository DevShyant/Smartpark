# Test Credentials (Emergent Google Auth — no passwords)

Owner/admin: dushyant120577@gmail.com (auto-admin via ADMIN_EMAILS in backend/.env on Google login)

Seeded test sessions (use header `Authorization: Bearer <token>` or cookie `session_token=<token>`):
- Customer: user_id `test-cust-1`, email test.customer@example.com, token `test_session_customer`
- Admin: user_id `test-admin-1`, email test.admin@example.com, token `test_session_admin`

Demo provider owning all sample listings: user_id `user_demo_partner` (partners@smartpark.demo) — no session.
To test provider role: set a test user's role to "provider" in db.users (or via admin API PUT /api/admin/users/{uid}/role).
See /app/auth_testing.md for creating sessions with mongosh.
