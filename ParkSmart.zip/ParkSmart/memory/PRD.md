# SmartPark – Integrated Smart Mobility Platform — PRD

## Original problem statement
MASTER PROMPT — BUILD SMARTPARK: INTEGRATED SMART MOBILITY PLATFORM. Tagline "Park Smart. Move Freely. Charge Green." One unified web app where users find and book parking spaces, rent vehicles (cars, bikes, scooters) and locate EV charging stations. Includes landing page (hero, 3 service cards, 3 CTA buttons, search/location, How It Works 5-step flowchart, benefits/USPs, Future Smart Mobility Hub vision, revenue model, footer), full booking flow (details → confirm → booking ID, status, directions, cancellation rules), parking module, rental module, EV module (no false live availability; demo data clearly labelled), auth & profile (saved locations, bookings), unified booking & payment (taxes, statuses Pending/Confirmed/Cancelled/Completed, sandbox gateway or clearly labelled demo), customer/provider/admin dashboards with role-based access, env vars for keys.
User choices: Emergent-managed Google sign-in, Razorpay, Google Maps, major Indian cities with ₹. "Add some images and videos to make this more attractive." Owner/admin: dushyant120577@gmail.com.

## Architecture
- Backend: FastAPI (server.py routes, core.py db/auth/roles, seed.py sample data), MongoDB (users, user_sessions, parkings, vehicles, ev_stations, bookings). Custom string ids, `_id` excluded.
- Frontend: React + Tailwind + shadcn, @vis.gl/react-google-maps (fallback map preview without key), Razorpay checkout.js (activates when keys set; otherwise DEMO mode).
- Pricing: units (hourly/daily/weekly/monthly) rounded up, service fee ₹20 parking / ₹49 rental, 18% GST. Commission 10% parking / 12% rental.
- Cancellation: pending anytime; parking until 1h before entry; rental until 24h before pickup; EV visit plans anytime before start.

## Personas
Customer (books), Provider (parking owners / rental fleets; request → admin approval), Admin (owner email via ADMIN_EMAILS).

## Implemented (2026-10-31)
- Landing page with hero video (saved locally /media/hero.mp4), CTAs, search, services, flowchart, USPs, future hub (concept image, labelled future), revenue model, footer with [placeholders].
- Parking/Rentals/EV explore pages with city select, GPS, search, filters, map; detail pages with live quote, availability check, booking.
- Checkout (Razorpay order/verify endpoints + labelled demo payment), booking confirmation page, cancel w/ rules, refunds (Razorpay refund API when live).
- EV: demo-labelled availability, "plan a visit" (not a reservation).
- Customer dashboard (overview, bookings filters, profile, saved locations, provider request); Provider dashboard (parking/vehicle CRUD, bookings, complete, earnings); Admin (stats, users/roles, provider approvals, listing toggle/delete, EV CRUD, all bookings).
- Tested: iteration_1 backend 20/20, frontend pass; follow-up fixes applied (stale data crash, admin moderation, delete guard, complete-before-start, defaults, price filters).

## Pending / Backlog
- P0: Add RAZORPAY_KEY_ID/SECRET (test) and REACT_APP_GOOGLE_MAPS_API_KEY — currently DEMO payment + map preview.
- P1: Collapsible mobile filters; shadcn date-time picker; Razorpay webhook; real EV operator API.
- P2: Provider subscriptions, email notifications, QR passes.
