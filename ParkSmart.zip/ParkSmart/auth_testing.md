# Auth-Gated App Testing Playbook (Emergent Google Auth)

Step 1: Create Test User & Session
mongosh --eval "
use('test_database');
var userId = 'test-user-' + Date.now();
var sessionToken = 'test_session_' + Date.now();
db.users.insertOne({user_id: userId, email: 'test.user.' + Date.now() + '@example.com', name: 'Test User', picture: '', role: 'customer', provider_status: 'none', saved_locations: [], created_at: new Date().toISOString()});
db.user_sessions.insertOne({user_id: userId, session_token: sessionToken, expires_at: new Date(Date.now() + 7*24*60*60*1000), created_at: new Date()});
print('Session token: ' + sessionToken);
"

Step 2: Backend: curl -H "Authorization: Bearer TOKEN" $API/api/auth/me

Step 3: Browser: add cookie {name: session_token, value: TOKEN, domain: <host>, path: /, httpOnly: true, secure: true, sameSite: None} then goto the app.

Roles: users.role in {customer, provider, admin}. Change directly in DB for tests.
Clean up: db.users.deleteMany({email: /test\.user\./}); db.user_sessions.deleteMany({session_token: /test_session/});
